# -*- coding: utf-8 -*-
"""邮箱验证码发送 - 基于 config 中的 SMTP 配置（默认为 QQ 邮箱）"""
import smtplib
import email.utils
from email.mime.text import MIMEText
from email.header import Header

import config


def smtp_configured():
    """邮件服务是否已完成配置"""
    return bool(config.SMTP_USER and config.SMTP_AUTH_CODE)


def send_code_email(to_email, code):
    """向指定邮箱发送登录验证码"""
    subject = '浩威刷题 - 登录验证码'
    minutes = max(1, config.EMAIL_CODE_TTL // 60)
    body = (
        '您好！\n\n'
        '您正在使用邮箱验证码登录「浩威刷题」。\n'
        f'您的验证码是：{code}\n\n'
        f'验证码 {minutes} 分钟内有效，请勿泄露给他人。\n'
        '若您没有请求该验证码，请忽略本邮件。\n\n'
        '—— 浩威刷题 团队\n'
    )
    msg = MIMEText(body, 'plain', 'utf-8')
    msg['Subject'] = Header(subject, 'utf-8')
    msg['From'] = config.SMTP_USER
    msg['To'] = to_email
    msg['Date'] = email.utils.formatdate(localtime=True)
    msg['Message-ID'] = email.utils.make_msgid(domain='haowei.local')

    with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=15) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.ehlo()
        smtp.login(config.SMTP_USER, config.SMTP_AUTH_CODE)
        smtp.sendmail(config.SMTP_USER, [to_email], msg.as_string())